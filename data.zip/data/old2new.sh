#!/bin/sh

OLD="$1"
NEW="$2"

for DIR in `find $OLD -type d`; do
    NR=`echo $DIR | sed -rn 's|^.*/md(.+)$|\1|g'`
    echo "DIR[$DIR] NR[$NR]"
done 